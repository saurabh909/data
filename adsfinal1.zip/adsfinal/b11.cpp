/*B11:You have a business with several offices; you want to lease phone lines to connect them up with each other; and the phone company charges different amounts of money to connect different pairs of cities. You want a set of lines that connects all your offices with a minimum total cost. Solve the problem by suggesting appropriate data structures. */


#include<iostream>
using namespace std;

class graph
{
int a[20][20];
int i,j,k,n;
public:

void read()
{
cout<<"\nEnter the no of offices";
cin>>n;
for(i=0;i<n;i++)
{
for(j=i;j<n;j++)
{
if(i==j)
a[i][j]=0;
else
{
cout<<"\nEnter the charge of the phoneline between office  "<<i<<" and "<<j<<" ";
cin>>a[i][j];
if(a[i][j]==0)
a[i][j]=0;
a[j][i]=a[i][j];
}
}
}
}

void print()
{
cout<<"\n the connections between the offices\n";

for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
cout<<a[i][j]<<" ";
}
cout<<endl;
}
}

void prims()
{

graph sp;
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
sp.a[i][j]=0;

}
}
int cost[20][20],edges; 
cout<<"\nEnter the starting office no";
cin>>k;
int v[10],d[10],f[10];

for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
if(a[i][j]==0)
cost[i][j]=100;
else
{
cost[i][j]=a[i][j];
}

}
}

for(i=0;i<n;i++)
{
v[i]=0;
d[i]=cost[k][i];
f[i]=k;
}
v[k]=1;

edges=n-1;
int v1,u,tc=0;
while(edges>0)
{

int min=100;
for(i=0;i<n;i++)
{
if(d[i]<min&&v[i]!=1)
{
min=d[i];
v1=i;
}
}
u=f[v1];
sp.a[u][v1]=min;
sp.a[v1][u]=min;
tc=tc+min;
v[v1]=1;
for(i=0;i<n;i++)
{
if(d[i]>cost[v1][i]&&v[i]!=1)
{
d[i]=cost[v1][i];
f[i]=v1;
          
}
}
edges--;
}

cout<<"\nVisited array\n";
for(i=0;i<n;i++)
{
cout<<v[i]<<" ";
}
cout<<endl;

cout<<"\nDistance array\n";
for(i=0;i<n;i++)
{
cout<<d[i]<<" ";
}
cout<<endl;
cout<<"\nFrom array\n";

for(i=0;i<n;i++)
{
cout<<f[i]<<" ";
}


cout<<"\n the spanning tree\n";

for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
cout<<sp.a[i][j]<<" ";
}
cout<<endl;
}
cout<<"\ntotal min cost :"<<tc;
}
};

int main()
{
graph g;
g.read();
g.print();
g.prims();


return 0;
}



