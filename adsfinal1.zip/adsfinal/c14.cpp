//C14:Consider telephone book database of N clients. Make use of a hash table implementation to quickly look up client�s telephone number.

#include<iostream>
using namespace std;

class node
{
public:
long int a;
node *next;
};

class hash1
{
node *oh[10];
long int ch[10];
int cf[10];
public:
hash1()
{
for(i=0;i<10;i++)
{
oh[i]=NULL;
ch[i]=0;
cf[i]=0;
}
}
int i,j,k,n;
long int p;

int fhash(long int q)
{
return q%10;
}


//open hashing functions

void oinsert(node *a[10],long int k)
{
int i;
i=fhash(k);
node *q=new node;
q->a=k;
q->next=NULL;
if(oh[i]==NULL)
oh[i]=q;
else
{
node *t=oh[i];
while(t->next!=NULL)
{
t=t->next;
}
t->next=q;
}
}

void display()
{
for(i=0;i<10;i++)
{
node *t=oh[i];
cout<<i<<"  ";
while(t!=NULL)
{
cout<<t->a<<"  ";
t=t->next;
}
cout<<endl;
}
}

void poin()
{
cout<<"Enter the phone no";
cin>>p;
oinsert(&oh[10],p);
}

void osearch()
{
cout<<"Enter the no";
cin>>p;
i=fhash(p);
node *t=oh[i];
while(t!=NULL)
{
if(t->a==p)
{
cout<<"\nClient found";
return;
}
t=t->next;
}
cout<<"\nClient not found";
}

 //close hashing functions

void cinsert(long int k)
{
i=fhash(k);
for(j=0;j<10;j++)
{
if(cf[i]==0)
{
cf[i]=1;
ch[i]=k;
return;
}
i=(i+1)%10;
}
}

void cdisplay()
{
cout<<"\n\nClose hashing\n";
for(i=0;i<10;i++)
{
cout<<ch[i]<<endl;
}
}

void pcin()
{
cout<<"Enter the phone no";
cin>>p;
cinsert(p);
}

void search()
{
cout<<"Enter the no";
cin>>p;
i=fhash(p);
for(j=0;j<10;j++)
{
if(ch[i]==p)
{
cout<<"\nClient found";
return;
}
i=(i+1)%10;
}
cout<<"\nClient not found";
}

};

int main()
{
hash1 h;
int x=0;
while(x!=3)
{
cout<<"Enter your choice\n1.Open Hashing\n2.Close Hashing\n3.Exit";
cin>>x;
switch(x)
{
case 1:
//open hashing using seperate chaining
while(x!=4)
{
cout<<"\nEnter your choice\n1.Insert\n2.Display\n3.Search\n4.Exit";
cin>>x;
switch(x)
{
case 1:
h.poin();
break;
case 2:
h.display();
break;
case 3:
h.osearch();
break;
case 4:
break;
default:
return 0;
}
}
break;
case 2:
//close hashing using linear probing
while(x!=4)
{
cout<<"\nEnter your choice\n1.Insert\n2.Display\n3.Search\n4.Exit";
cin>>x;
switch(x)
{
case 1:
h.pcin();
break;
case 2:
h.cdisplay();
break;
case 3:
h.search();
break;
case 4:
break;
default:
return 0;
}
}
break;
default:
return 0;
}
}
return 0;
}


