/*G26:Any application defining scope of Formal parameter, Global parameter, Local parameter accessing mechanism and also relevance to private, public and protected access.  Write a Java program which demonstrates the scope rules of the programming mechanism. */


import java.lang.*;
import java.util.Scanner;
class A
{

public int div(int a,int b)
{
return a/b;
}

public void dzexception()
{
int res=0;
getdata();
try
{
res=div(x,y);
System.out.println("Div : "+res);
}
catch(ArithmeticException ex)
{
System.out.println("Exception occured");
}
}

int x,y;

public void getdata()
{

System.out.println("Enter two no");
Scanner sc=new Scanner(System.in);
x=sc.nextInt();
y=sc.nextInt();
sc.close();
}

};

class B
{
static <T> void genericDisplay (T element) 
{ 
System.out.println(element.getClass().getName() +" = " + element); 
} 

public static void main(String args[])
{
A as=new A();
as.dzexception();
C cs=new C();
cs.otexception();
genericDisplay(11); 
genericDisplay("GeeksForGeeks"); 
genericDisplay(1.0); 
}

};








