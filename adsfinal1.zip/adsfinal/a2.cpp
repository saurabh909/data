/*A2: Beginning with an empty binary search tree, Construct binary search tree by inserting the values in the order given. After constructing a binary tree - i. Insert new node ii. Find number of nodes in longest path  iii. Minimum data value found in the tree  iv. Change a tree so that the roles of the left and right pointers are swapped at every node  v.  Search a value  */

#include<iostream>
using namespace std;

class node
{
public:
int data;
node *left;
node *right;
};

class tree
{
node *root;
public:
tree()
{
root=NULL;
}
int i,j,k,m,n;

node* create(node *t)
{
int x;
cout<<"\nEnter the data and enter -1 for NULL";
cin>>x;
if(x==-1)
return 0;
root=insert(t,x);
return root;
}

node* insert(node *t,int x)
{
node *p,*q,*r;
p=new node;
p->data=x;
p->left=NULL;
p->right=NULL;

if(t==NULL)
t=p;
else
{
q=t;
while(q!=NULL)
{r=q;
if(x>q->data)
q=q->right;
else
q=q->left;
}
if(x>r->data)
{
r->right=p;
}
else
r->left=p;
return t;
}
}

void pcreate()
{
node *p;
p=create(root);
}

void in(node *t)
{
if(t!=NULL)
{
tree(t->left);
cout<<(t->data)<<" ";
pre(t->right);
}
}

void pubin()
{
tree(root);
}

void min()
{
node *t=root;
while(t->left!=NULL)
{
t=t->left;
}
cout<<"\nMinimum Data: "<<t->data;
}

int search(node *t,int x)
{
if(t!=NULL)
{if(x==t->data)
cout<<"\nElement found";
else
{
if(x>t->data)
{
t=t->right;
search(t,x);
}
else if(x<t->data)
{
t=t->left;
search(t,x);
}
}
}
else
{
cout<<"\nElement not found";
return 0;
}
}

void psearch()
{
int x;
cout<<"\nEnter the element to be searched";
cin>>x;
search(root,x);
}

int height(node *t)
{
if(t!=NULL)
{
if(t->left!=NULL||t->right!=NULL)
{
int count=1+max(height(t->right),height(t->left));
return count;
}
else
return 0;
}
else 
return 0;
}

int max(int a,int b)
{
if(a>b)
return a;
else return b;
}

void pheight()
{
int x;
x=height(root);
x++;
cout<<"\nNo of nodes in longest path :"<<x;
}

node* swap(node *t)
{
node *p;
if(t!=NULL)
{
p=t->left;
t->left=swap(t->right);
t->right=swap(p);
return t;
}
else
return 0;
}

void pswap()
{
node *p;
p=swap(root);
pubin();
}

};

int main()
{
tree t;
int x=0;
while(x!=7)
{
cout<<"\nEnter the choice\n1.Insert\n2.Display\n3.No of nodes in longest path\n4.Minimum Data\n5.Swap tree\n6.Search\n7.Exit";
cin>>x;
switch(x)
{
case 1:
t.pcreate();
break;
case 2:
cout<<"\nElements of bst: ";
t.pubin();
break;
case 3:
t.pheight();
break;
case 4:
t.min();
break;
case 5:
cout<<"\nBst after swapping: ";
t.pswap();
break;
case 6:
t.psearch();
break;
case 7:
break;
default:
return 0;
}
}
return 0;
}



