/*C15:Implement all the functions of a dictionary (ADT) using hashing. Data:  Set of (key, value) pairs, Keys are mapped to values, Keys must be comparable, Keys must be unique Standard Operations:  Insert(key, value), Find(key), Delete(key) */

#include<iostream>
#include<string.h>
using namespace std;

class node
{
public:
string key;
string value;
node *next;
};

class hash1
{
node *oh[10];
public:
hash1()
{
for(i=0;i<10;i++)
{
oh[i]=NULL;
}
}
int i,j,k,n;
string a,b;

int fhash(string q)
{
return q.size()%10;
}


//open hashing functions

void oinsert(string k,string v)
{
int i;
i=fhash(k);
node *q=new node;
q->key=k;
q->value=v;
q->next=NULL;
if(oh[i]==NULL)
oh[i]=q;
else
{
node *t=oh[i];
while(t->next!=NULL)
{
t=t->next;
}
t->next=q;
}
}

void display()
{
for(i=0;i<10;i++)
{
node *t=oh[i];
cout<<i<<"  ";
while(t!=NULL)
{
cout<<t->key<<": "<<t->value<<"  ";
t=t->next;
}
cout<<endl;
}
}

void poin()
{
cout<<"Enter the key and value";
cin>>a>>b;
oinsert(a,b);
}

void osearch()
{
cout<<"Enter the key";
cin>>a;
i=fhash(a);
node *t=oh[i];
while(t!=NULL)
{
if(t->key==a)
{
cout<<"key found\n"<<t->key<<": "<<t->value;
return;
}
t=t->next;
}
cout<<"\nkey not found";
}

void del()
{
cout<<"Enter the key";
cin>>a;
i=fhash(a);
node *t=oh[i];
if(t->key==a)
{
oh[i]=t->next;
cout<<"key is deleted";
}
else
{
while(t!=NULL)
{
if(t->next->key==a)
{
node *q;
q=t->next;
t->next=q->next;
cout<<"key is deleted";
return;
}
t=t->next;
}
cout<<"\nkey not found";
}
}

};

int main()
{
hash1 h;
int x=0;
while(x!=5)
{
cout<<"\nEnter your choice\n1.Insert\n2.Display\n3.Search\n4.Delete\n5.Exit";
cin>>x;
switch(x)
{
case 1:
h.poin();
break;
case 2:
h.display();
break;
case 3:
h.osearch();
break;
case 4:
h.del();
break;
case 5:
break;
default:
return 0;
}
}
return 0;
}




