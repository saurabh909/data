/*F23: Department maintains a student information. The file contains roll number, name, division and address.   Allow user to add, delete information of student. Display information of particular employee.  If record of student does not exist an appropriate message is displayed. If it is, then the system displays the student details. Use sequential file to main the data.*/

#include<iostream>
#include<iomanip>
#include<fstream>
#include<string.h>
using namespace std;
struct student
{
int rollno;
char name[20];
char div;
char address[20];
int status;
};

class sequential
{
char master[30];
fstream mas;
public:
sequential(char *a)
{
strcpy(master,a);
mas.open(master,ios::binary|ios::in|ios::trunc);
if(mas.fail())
mas.open(master,ios::binary|ios::out);
mas.close(); 
}

void read()
{
student rec;
int i=1,n;
mas.open(master,ios::binary|ios::in);
mas.seekg(0,ios::end);
n=mas.tellg()/sizeof(student);
mas.seekg(0,ios::beg);
for(i=1;i<=n;i++)
{
mas.read((char*)&rec,sizeof(student));
if(rec.status!=1)
cout<<"\n"<<rec.rollno<<"  "<<rec.name<<"  "<<rec.div<<"  "<<rec.address;
else
cout<<"\n"<<i<<" is deleted";
}
mas.close();
}

void write(student rec1)
{
student rec;
int i,k,n;
mas.open(master,ios::in|ios::out);
rec1.status=0;
mas.seekg(0,ios::end);
n=mas.tellg()/sizeof(student);
if(n==0)
{
mas.write((char*)&rec1,sizeof(student));
mas.close();
return;
}
else
{
i=n-1;
while(i>=0)
{
mas.seekg(i*sizeof(student),ios::beg);
mas.read((char*)&rec,sizeof(student));
if(rec.rollno>rec1.rollno)
{
mas.seekp((i+1)*sizeof(student),ios::beg);
mas.write((char*)&rec,sizeof(student));
i--;
}
else
break;
}
i++;
mas.seekp(i*sizeof(student),ios::beg);
mas.write((char*)&rec1,sizeof(student));
mas.close();
}
}

void search(int x)
{
student rec;
int i,n;
mas.open(master,ios::binary|ios::in);
mas.seekg(0,ios::end);
n=mas.tellg()/sizeof(student);
mas.seekg(0,ios::beg);
for(i=0;i<n;i++)
{
mas.read((char*)&rec,sizeof(student));
if(rec.rollno==x&&rec.status==0)
{
cout<<"\nStudent found.\n";
cout<<rec.rollno<<" "<<rec.name<<" "<<rec.div<<" "<<rec.address;
mas.close();
return;
}
}
cout<<"student not found";
mas.close();
}

void ldelete(int x)
{
student rec;
int i,n;
mas.open(master,ios::binary|ios::in|ios::out);
mas.seekg(0,ios::end);
n=mas.tellg()/sizeof(student);
mas.seekg(0,ios::beg);
for(i=0;i<n;i++)
{
mas.read((char*)&rec,sizeof(student));
if(rec.rollno==x&&rec.status==0)
{
rec.status=1;
mas.seekp(i*sizeof(student),ios::beg);
mas.write((char*)&rec,sizeof(student));
cout<<"student record successfully deleted";
mas.close();
return;
}
}
cout<<"\nStudent record not in the system";
mas.close();
}

void pack(int x)
{
student rec;
fstream temp;
int n,i;
temp.open("temp.txt",ios::in|ios::out|ios::trunc);
mas.open(master,ios::in|ios::out|ios::binary);
mas.seekg(0,ios::end);
n=mas.tellg()/sizeof(student);
mas.seekg(0,ios::beg);
for(i=0;i<n;i++)
{
mas.read((char*)&rec,sizeof(rec));
if(rec.rollno!=x&&rec.status==0)
{
temp.write((char*)&rec,sizeof(student));
}
}
mas.close();
temp.close();
mas.open(master,ios::in|ios::out|ios::trunc);
temp.open("temp.txt",ios::in|ios::out|ios::binary);
temp.seekg(0,ios::end);
n=temp.tellg()/sizeof(student);
temp.seekg(0,ios::beg);
for(i=0;i<n;i++)
{
temp.read((char*)&rec,sizeof(rec));
mas.write((char*)&rec,sizeof(student));
}
mas.close();
temp.close();
}

};

int main()
{
sequential ob("master.txt");
int i,x,y=0;
student rec1;
while(y!=6)
{
cout<<"\nEnter the choice\n1.Insert\n2.Display\n3.Search\n4.Logical delete\n5.Permanent delete\n6.Exit  ";
cin>>i;
switch(i)
{
case 1:
cout<<"\nEnter the roll no,Name,Div,address";
cin>>rec1.rollno>>rec1.name>>rec1.div>>rec1.address;
ob.write(rec1);
break;
case 2:
ob.read();
break;
case 3:
cout<<"\nEnter roll no to search";
cin>>x;
ob.search(x);
break;
case 4:
cout<<"\nEnter roll no to logically delete";
cin>>x;
ob.ldelete(x);
break;
case 5:
cout<<"\nEnter roll no to permanntly delete";
cin>>x;
ob.pack(x);
break;
case 6:
return 0;
default:
return 0;
}
}
return 0;

}


