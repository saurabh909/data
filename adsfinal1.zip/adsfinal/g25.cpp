//G25:Implement the Heap/Shell sort algorithm implemented in Java demonstrating heap/shell data structure with modularity of programming language

import java.util.Scanner;

class Msort
{
public int[] max=new int[21];
Scanner sc=new Scanner(System.in);
public int n,i,j,k,l,m;
void getdata()
{
System.out.println("Enter the no of elements");
n=sc.nextInt();
System.out.println("Enter the elements");
for(i=0;i<n;i++)
{
m=sc.nextInt();
insert(m);
}
}


void insert(int x)
{
j=max[0];
j=j+1;
max[j]=x;
max[0]=j;
upadjust(j);
}

void upadjust(int x)
{
while(max[x/2]<max[x]&&x>1)
{
int temp;
temp=max[x];
max[x]=max[x/2];
max[x/2]=temp;
x=x/2;
}
}


void display()
{
System.out.println("Max heap: ");
for(i=0;i<=n;i++)
{
System.out.print(+max[i]," ");
}
}

void dsort()
{
System.out.println("Sorted heap: ");
for(i=0;i<n;i++)
{
delete();
}
}

void delete()
{
j=max[0];
k=max[1];
max[1]=max[j];
max[j]=k;
System.out.print(+k," ");
j=j-1;
max[0]=j;
downadjust(j);
}

void downadjust(int x)
{
l=1;
int flag=1;
while(2*l<=x&&flag==1)
{
m=2*l;
if(m+1<=x&&max[m+1]>max[m])
m=m+1;
if(max[l]>max[m])
flag=0;
else
{
k=max[l];
max[l]=max[m];
max[m]=k;
l=m;
}
}
}

};

class Sort
{
public static void main(String args[])
{
Msort ms=new Msort();
ms.getdata();
ms.display();
ms.dsort();
}
};


